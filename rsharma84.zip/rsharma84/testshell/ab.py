import pandas as pd


def fun1(*args):
    print("i am in fun1" ,args,type(args))
    print("value of i",args[2],args[1])

def fun2(**arg):
    print(arg,type(arg))
    print(arg["a"])

def main():
    pf=pd.read_csv("abc.txt",header=None)
    #print(pf,type(pf))
    for inx,row in pf.iterrows():
        print("index=",inx,row[0])

    print("i am in main")
    #for i in range(1,3):
    #    y="Rajesh"
    #    fun1(i,y,i+1)
    fun2(a=10,b="raj",c=10.5)

if __name__=="__main__":
    main()


