#!/bin/bash

echo "Insert the price "
read float1
echo "this is price with tax"
echo "scale=2; $float1/1.18" |bc -l
x=`echo "scale=2; $float1/1.18" |bc`
echo "value of x is $x"
read -p "Press any key to continue"

exit 0
