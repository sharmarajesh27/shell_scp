#!/bin/bash

a=$(cat aa.txt)
b=$(cat bb.txt)
c=$(cat cc.txt)

if [ "$a" = "$b" ] 
then
  echo "hello a and b  file matched"

  if [ "$a" = "$c" ]
  then 
	 echo "file a ,b ,c matched"
  else
	  echo "file c is not matching with a and b"
  fi 

fi


