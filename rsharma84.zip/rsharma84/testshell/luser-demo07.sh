#! /bin/bash

# ${#}   return the count of arguments supplied

while [[ "${#}" -gt 0 ]]
do
	echo "Number of parameters ${#}"
	echo "Paramters 1 ${1}"
	echo "Paramters 2 ${2}"
	echo "Paramters 3 ${3}"
	echo "Paramters 4 ${4}"
	echo
	shift
done
