#! /bin/bash


echo "You executed this command ${0}"

echo "YOu used $(dirname ${0}) as the path to the $(basename ${0}) script."

echo "total arguemnt passed in commnad line ${#} "

NUMBER_OF_ARGUMENTS="$#"

echo " argument count is $NUMBER_OF_ARGUMENTS"

# we can extract varaible value either by ${name_of_vairable} or by $name_of_variable  -remember my dear

if [[ "$NUMBER_OF_ARGUMENTS" -lt 1 ]]
then
	echo "No arguemnt supplied with command"
	exit 1
else
	echo "Total number of argument passed $NUMBER_OF_ARGUMENTS and they are ${@}"
fi

# for loop will print all the arguments one by one --${@} stores all the arguments

for USER_NAME in "${@}"
do
	PASSWORD=$(date +%s%N)
	echo "$USER_NAME : $PASSWORD"
done

# ${*}   combime all the arguemnt to one
for USER_NAME in "${*}"

do
	PASSWORD=$(date +%s%N)
	echo "$USER_NAME : $PASSWORD"
done
