#!/bin/bash


LIMIT=2

sort -n abc.txt |uniq -c |while read COUNT NUM
do 
	if [[ "${COUNT}" -gt "${LIMIT}" ]]
	then
		echo "you have cross the limit of login i.e $COUNT"
	else

		echo "$NUM you have login numebr $COUNT"
	fi
done	
