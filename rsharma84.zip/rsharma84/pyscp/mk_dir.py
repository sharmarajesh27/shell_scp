import os

directory="myos_scripts"

parent_dir=os.path.dirname(__file__)
print("parent dir is",parent_dir)

path=os.path.join(parent_dir,directory)

os.mkdir(path)

