#!/bin/bash

read -p "What is your first name?: " firstname
echo
read -p "What is your surname/family name?: " famname
echo 
read -N 4 -p "What is your extension number?: " extno
echo
echo
read -N 4 -s -p "What access code would you like to use when dialing in?: " accessCode
echo
echo 
#echo "FirstName,Family_Name,Extnesion_No,PIN" >> user_data.csv
echo -e  "$firstname,$famname,$extno,$accessCode " >> user_data.csv
