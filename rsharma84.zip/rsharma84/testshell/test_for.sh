#!/bin/bash

for element in 1 2 3 4
do
	echo "this is element $element"
done



