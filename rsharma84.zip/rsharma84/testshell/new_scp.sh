#!/bin/bash

string="Hi im a adding new line at"

echo "$string  at" >> /home/rsharma84/testshell/Cron_output.txt
date >> /home/rsharma84/testshell/Cron_output.txt

