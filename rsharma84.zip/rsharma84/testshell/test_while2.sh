#!/bin/bash

i=1
while read -r line 
do
	echo "line number $i is == > $line"
	i=$((i+1))
done < "$1"

# testing the output of command with whil loop

while read -r line 
do 
	echo "output of command ls -l is==> $line"
done < <(ls -l)
