#! /bin/bash

# hello from the main user
echo "hello"
