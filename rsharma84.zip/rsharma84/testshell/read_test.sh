#!/bin/bash

x=${1:-10}
echo "first argument is $x"
y=${2:-20}
echo "first argument is $y"
z=$(($x+$y))
echo "$#output is $z"

read -t 5 -p "Enter your name: " name
read -t 5 -p "Enter your age: " age
read -t 5 -p "Enter your car name: " car
read -s -p "Enter the OTP:" OTP
echo -e "\n$name is $age years old and drving $car "

if [[ $OTP -eq "1234" ]];
then 
	echo "Your OTP verified"
else
	echo "OTP is wrong"
fi

