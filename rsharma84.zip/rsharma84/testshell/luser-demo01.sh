#! /bin/bash

# hello from the main user
echo "hello"

WORD='sript'
echo "$WORD"
echo "this is a shell $WORD"
echo "this is a shell ${WORD}"
echo "${WORD}ing is good"

ENDING='ed'
echo "this is ${WORD}${ENDING} ."

echo "this is $WORD$ENDING "
ENDING="ing"
echo "this is ${WORD}${ENDING} ."
