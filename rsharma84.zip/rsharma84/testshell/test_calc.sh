#!/bin/bash

echo $(( "$*" ))
echo $#
