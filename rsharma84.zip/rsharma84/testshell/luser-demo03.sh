#! /bin/bash

echo "Your id is ${UID}"
#or u can use below line
echo "You ID is $UID"

UID_TO_TEST_FOR='1000'

if [[ "${UID}" -ne "${UID_TO_TEST_FOR}" ]]
then
	echo "Your UID does not macth ${UID_TO_TEST_FOR} ."
	exit 1
fi


USER_NAME=$(id -un)

# ${?} store the exit status of last command  

if [[ "${?}" -ne 0 ]]
then
	echo "The id command did not execute successfully"
	exit 1
fi

echo "You user name is ${USER_NAME}"

USER_NAME_TO_TEST_FOR='rajesh42'

if [[ "${USER_NAME}" = "${USER_NAME_TO_TEST_FOR}" ]]
then
	echo "You user name matches ${USER_NAME_TO_TEST_FOR}"

fi

if [[ "${USER_NAME}" != "${USER_NAME_TO_TEST_FOR}" ]]
then
	echo "your user name does not match ${USER_NAME_TO_TEST_FOR} ."
	exit 1
fi

exit 0
