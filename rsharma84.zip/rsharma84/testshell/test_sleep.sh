#!/bin/bash

TOTAL_SEC=""

while getopts "m:s:" time_val
do
	case $time_val in 
		m) TOTAL_SEC=$((TOTAL_SEC+OPTARG*60 )) ;;
		s) TOTAL_SEC=$((TOTAL_SEC+OPTARG)) ;;
		?) echo "Correct input not provided"
			exit 1 ;;
	esac
done
echo "Wait for $TOTAL_SEC seconds"

while [ $TOTAL_SEC -gt 0 ]
do
	echo "$TOTAL_SEC"
	TOTAL_SEC=$((TOTAL_SEC-1))
	sleep 1s
done

echo "Time up"
