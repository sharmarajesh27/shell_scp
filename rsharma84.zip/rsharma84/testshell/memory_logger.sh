#!/bin/bash

if [ -d "$HOME/testshell/test" ]
then
	echo "folder exist here"
else
	mkdir  "$HOME/testshell/test"
	if [ $? -eq 0 ]
	then
		echo "folder created created successfully at $HOME/testshell/"
	fi

fi
echo "---------------------------------------" >>"$HOME/testshell/test/memory.log"
date >> "$HOME/testshell/test/memory.log"
free  -mh >> "$HOME/testshell/test/memory.log"


