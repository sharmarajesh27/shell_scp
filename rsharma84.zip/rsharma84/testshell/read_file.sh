#!/bin/bash

if [ "$#" -lt 1 ]
then
	echo "file name to be read not provided"
	echo "Usage : $(basename $0) filename "
	exit 1
else 
	echo "Readind the file $1"
	
fi


while read -r line
do
	echo "${#line} === > $line"
done < "$1"
