#!/bin/bash

xx="rajesh"
yy="rajesh"
zz="rajesh1"

if [[ $xx = $yy  ||  $yy = $zz ]]
then
	echo "names matched"
else
	echo "names not matched"
fi

if [ -e "b.txt" ]
then
	echo "file is there "
else
	echo "file missing"
fi
aa=$(cat a.txt)	#aa equals the contents of file a
bb=$(cat b.txt)
cc=$(cat c.txt)


if [[ "$aa" = "$bb"  && "$aa" = "$cc" ]]
then
	        rm a.txt
	else
		echo " a.txt did not match both the files"
		       
fi

# check if a file is executables

if [ -e "$1" ]
then 
	if [ -x "$1" ]
	then
		echo "file exist and executable"
	else
		echo "file exist but not executable"
	fi
else
	echo "file did not exit"
fi
	
