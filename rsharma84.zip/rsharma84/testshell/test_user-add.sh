#!/bin/bash

NO_OF_ARGS="$#"

USER_ID="$UID"

if [[ "$USER_ID" -ne 0 ]]
then
	echo "Please run the script as root user"
	exit 1
fi

if [[ "$NO_OF_ARGS" -lt 1 ]]
then
	echo "You have not provide the user detail\n"
	echo "Please provide the user name and password for new user"
	echo "Usage: ${0} USER_NAME [COMMENT]....."
	exit 1
fi

USER_NAME="$1"

# we are shifting so that user name no longer in arguments and rest of argumnets can be treated as comment

shift
COMMENT="${@}"

PASSWORD=$(date +%s%N)


useradd -c "$COMMENT" -m "$USER_NAME"

if [[ "$?" -ne 0 ]]
then
	echo "User name not created, try again"
	exit 1
fi

echo -e "$PASSWORD\n$PASSWORD" | passwd "$USER_NAME"
if [[ "$?" -ne 0 ]]
then
	echo "Password not set for user $USER_NAME"
	exit 1
fi

passwd -e "$USER_NAME"
echo 'Username is :'
echo "$USER_NAME"
echo 
echo 'password is '
echo "$PASSWORD"
echo
echo 'HOST_NAME is :'
echo "$HOSTNAME"
exit 0
