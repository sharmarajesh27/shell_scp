#!/bin/bash

#IFS=,
echo "Using \"\$*\":"
echo "$*"
for a in "$*"; do
    echo $a;
 done

echo -e "\nUsing \$*:"
echo $*
for a in $*; do
    echo $a;
done

echo -e "\nUsing \"\$@\":"
echo "$@"
for a in "$@"; do
    echo $a;
done

echo -e "\nUsing \$@:"
echo $@
for a in $@; do
     echo $a;
done              
