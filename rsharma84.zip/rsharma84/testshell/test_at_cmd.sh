#!/bin/bash

mkdir at_dir
touch at_dir/file{01..20}.txt

