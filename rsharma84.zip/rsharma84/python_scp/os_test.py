#!/usr/bin/python3



import os

dir_name="test1"

parent_dir=os.getcwd()

path1=os.path.join(parent_dir,dir_name)

print("path is",path1)

os.mkdir(path1)

print("Directory '%s' created "% dir_name)

