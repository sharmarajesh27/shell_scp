#!/bin/bash

case "$1"  in 
	start) 
		echo "starting" 
		;;
	stop|exit|--stop|--exit) 
		echo "stopping" 
		;;
	status|state)
	       	echo "status" 
		;;
	restart)
	       	echo 'restarting' 
		;;
	*)
		echo 'supply a valid option' 
		exit 1
		;;

esac
			
