#!/bin/bash

FILE="/tmp/data"

# head -1 /etc/passwd > ${FILE}

read LINE < ${FILE}

echo "out of file is $LINE"
