#!/bin/bash

#: before argument menas that u want to supress errors
#: after the argument means this opetion need addtion parameters that will be stored in $OPTARG
# if ther is no : after any argument than it means this argument don't required addtional value
# like in this script -a and -p argument need additoanl value w when called with script but -r don't need additional parameter
#$(basename $0) will give only the basename of the scirptname we are using without path detail lile ./abc.sh. here output will be like abc.sh

while getopts ":a:rp:" param
do
	case $param in 
		a) echo "You have selected option a with $OPTARG" ;;
		r) echo "You have selected option r with $OPTARG" ;;
		p) echo "You have selected option p with $OPTARG" ;;
		\?) echo "Usage:  $(basename "$0") [-a argument] [-r] [-p argument] "
		     exit 1 	;;
	esac
done


echo "variable used is $1 and count is $OPTIND"
shift "$((OPTIND-1))"
echo "variable used is $1 "
echo "all the lsit $@"

i=1
for  x in "$@"
do
      echo "value at count $i is $x"
      i=$((i+1))
done
echo "variable used is $1"
