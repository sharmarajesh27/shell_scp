#! /bin/bash

awk -F ":" '{print $1 ,S4}' /etc/passwd
