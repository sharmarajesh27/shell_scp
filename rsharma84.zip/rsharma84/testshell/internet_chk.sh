#!/bin/bash

date >> ~/testshell/Internet_status.log

ping -c 3 google.com &> /dev/null

if [ $? -eq 0 ]
then 
	echo "Internet connected ">>Internet_status.log
else
	echo "Internet : Disconnected ">>Internet_status.log
fi

echo "RAM USAGE : " >> Internet_status.log
free -h | grep "Mem"  >> Internet_status.log

echo "Swap USAGE : " >> Internet_status.log

free -h | grep "Swap" >> Internet_status.log

echo  "" >> Internet_status.log

echo "DISH USAGE : " >> Internet_status.log
df -h >> Internet_status.log

echo "==================================================" >> Internet_status.log


