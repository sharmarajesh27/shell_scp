#!/bin/bash

log() {
        local VERBOSE="$1"
	shift
	local MESSAGE="${@}"
	if [[ $VERBOSE = 'true' ]]
	then 
	echo "${MESSAGE}"
	fi

}	

log 'true' 'HELLO'

log 'true' 1 2 3 4 5 

backup_file() {

local FILE="$1"

if [[ -f "$FILE" ]]
then
	local BACKUP_FILE="/var/tmp/$(basename $FILE).$(date +%F-%N)"
	log 'true' "backing up $FILE to $BACKUP_FILE"
	cp -p $FILE $BACKUP_FILE
else
	return 1
fi

}

backup_file '/etc/passwd'

if [[ $? -eq '0' ]]
then
	echo 'File backup succeeded'
else
	echo 'File backup failed'
fi

