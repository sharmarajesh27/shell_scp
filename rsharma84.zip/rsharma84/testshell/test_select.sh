#!/bin/bash
PS3="Please select the brand of car you own "

select brand in Suzuki Kia Tesla Hundai GM Ford;
do
	echo "you have selected the brand $brand"

	case "$brand" in 
		"Suzuki") echo "You have chosed (Suzuki)  one of the leading card manufacturer in India" ;;
		"Kia") echo "Seltos is most popular model from Kia" ;;
		"Tesla") echo "Tesla have not started manufacturing in India " ;;
		"Hundia"|"GM"|"Ford") echo "Nice choice " ;;
		*) echo "You have some different brand" ;;
	esac
break

done
