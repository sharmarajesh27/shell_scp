#!/bin/bash

username="RAJESH"
Age=24
year=2012

echo "${username}"
test=$(($Age+10))
test1=$((Age+year))
test2=$(($Age+$year))
test3=$((${Age}+10))

echo "$test , $test1, $test2"

echo "testting 3, $test3"
