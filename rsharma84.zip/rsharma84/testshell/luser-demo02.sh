#! /bin/bash

echo "Your UID $UID"

echo "Your UIS is ${UID}"

USER_NAME=$(id -un)
USER_NAME1=`id -un`
echo "my username is $USER_NAME"
echo "new user name is $USER_NAME1"

# double quotes in if statement means the value of variable--u can also remove the quotes ,,this will have same impact
if [[ "${UID}" -eq 0 ]]
then 
	echo 'You are a root user'
else
	echo 'You are not a root:'
fi
