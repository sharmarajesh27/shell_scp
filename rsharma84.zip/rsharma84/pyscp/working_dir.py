#!/bin/python

import os

cwd=os.getcwd()

print("Current working dir is ",cwd)

