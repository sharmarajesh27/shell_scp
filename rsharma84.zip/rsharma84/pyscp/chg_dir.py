
import os

cwd=os.getcwd()

print("current working directory is",cwd)

os.chdir('../')

print("changed",os.getcwd())
