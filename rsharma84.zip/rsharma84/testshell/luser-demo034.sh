#! /bin/bash

read -p 'Enter your name ' USER_NAME
echo "inout is $USER_NAME "

read -p  'Enter the name of the perso who this account is for ' COMMENT

read -p 'Enter the password for your account ' PASSWORD

useradd -c "${COMMENT}" -m ${USER_NAME}


echo -e "$PASSWORD\n$PASSWORD" |passwd  "$USER_NAME"
passwd -e ${USER_NAME}
