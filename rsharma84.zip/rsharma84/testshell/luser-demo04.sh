#! /bin/bash

PASSWORD="${RANDOM}"
echo "${RANDOM}"

PASSWORD="${PASSWORD}${PASSWORD}${PASSWRD}"
echo "$PASSWORD"

PASSWORD=$(date +%s%N)
echo "$PASSWORD"

S='!@#$%^&*()_+='

SPECIAL=$(echo ${S} | fold -w2 |shuf |head -1)
echo "${SPECIAL}"

echo "${PASSWORD}${SPECIAL}"
