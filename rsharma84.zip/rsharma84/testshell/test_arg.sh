#!/bin/bash

touch "$@"
