#!/bin/bash

read -n 2 -p "small n opation with read " p2
echo
echo   "value is $p2"

read -N 2 -p "Capital N with read" N2

echo "captital ---value is $N2 "

read -a names 
echo "array is ---> ${names[@]} "   # curly bracket are must to access the array elements
echo
#echo "array is ==> $names[@]"

len1=${#names[@]}
idx=${!names[@]}   #${!names[@]}   this will give the indexes of this array

echo "indexs of names array are $idx"

# array eleements are accessed using ${arr[index]}
echo 
echo "len1--$len1"
echo 
echo "${names[0]} and ${names[1]}"

