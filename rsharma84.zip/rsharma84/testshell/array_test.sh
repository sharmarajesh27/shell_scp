#!/bin/bash

readarray -t my_arr < <(ls ~/testshell/*.txt)

for ele in  "${my_arr[@]}"
do
	echo "$ele"
done
