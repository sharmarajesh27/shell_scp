#!/bin/bash

echo "Starting the backup process for $USER "
current_dir=$(pwd)
echo "Taking the back up for $current_dir "

echo "Storing the back up file in $HOME"

tar -cf ~/my_bakcup_"$(date +%d-%m-%Y_%H-%M-%S)".tar /$HOME/testshell/* 2>/dev/null
echo "file stored in $HOME/testshell/ dir "

