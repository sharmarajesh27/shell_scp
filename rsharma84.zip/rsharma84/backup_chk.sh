#!/bin/bash

PS3="Please select the action you want to perform on file => "

select opt in Copy Delete Zip Unzip Backup No_action
do 
	echo "You have seleced the $opt "
	#exit 0
	if [ $opt != "No_action" ] && [ $opt != "Unzip" ] && [ $opt != "Backup" ] && [ $opt != "Delete" ]
	then
		read -r -p "Please provide the file name" file
		if [ ! -f "$file" ]
		 then
		     echo "not file "
		     exit 1
		 fi
	
		
	fi

	

	case $opt in 
		Copy) echo "Performing copy operation" 
			

			echo "youe have selected ==> $file"

			current_time=$(date +%m-%d-%Y_%T)
			copied="copied"
			new_file=$file.$copied.$current_time

			echo "New file name ===> $new_file"
			cp "$file" "$HOME/$new_file"
			echo "-----file copied-----------"
			#exit 0
			;;
		Delete) echo "You have selected to delete the old files"
			read -r -p "How much old files you want to delete. Enter Days: " old_day
			readarray -t file <  <( find "$HOME/" -type f -name  "*.txt" -mtime  +$old_day)
			for fname in "${file[@]}"
			do
				echo "delte the file $fname"
				rm -i $fname
			done
			echo "Listed files files deleted"
			;;




		Zip) echo 'You have selected the Zip option  '
		     echo "youe have selected ==> $file"
		     read -r -p "Please confirm if you want to keep the original file y/n" flag
		     if [ "$flag" = "y" ]
		     then 
			     gzip -k "$file"
			     if [ $? -eq "0" ]
			     then
				     echo "file compressed"
				     echo
		             else 
				     echo "error on file compression "
				     echo
			     fi 
		    else 
			    gzip "$file"
			    if [ $? -eq "0" ]
                            then
                                 echo "file compressed"
                                 
                            else
				echo "Error in file compression"
			    fi
		     fi

			;;

		Unzip) echo "You have selected the Unzip option "
			read -r -p "Eneter the file you want to unzip " file

			gzip -d "$file"

			if [ $? -eq 0 ]
			then
			     echo "file Uncompressed"
			     echo
			else
			     echo "error in file Un-compression "
			    echo
			fi

			;;

			                        
		Backup) echo "You have selected the option Backup  "
			bk_time=$(date  +%m-%d-%m)
			tar -cf file_bk.$bk_time.tar *.txt
			mv file_bk.*.tar ~/testshell/bkup
			echo "backup done and moved to folder $HOME/testshell/bkup"
			echo 


		;;			
						
		No_action) echo "Bye Bye "
			exit 0 ;;

	esac
echo "==============================Select again from Main menu==========================================="
echo 

done
